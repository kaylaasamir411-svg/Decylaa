// solvers/pert-cpm.js
function computePERT(activities){
  const map = {};
  activities.forEach(a=> map[a.id]=Object.assign({},a));
  const indeg = {}; activities.forEach(a=> indeg[a.id]=0);
  activities.forEach(a=> a.preds.forEach(p=> indeg[a.id]++));
  const q = [];
  for(const id in indeg) if(indeg[id]===0) q.push(id);
  const topo=[];
  while(q.length){ const u=q.shift(); topo.push(u);
    activities.forEach(a=>{ if(a.preds.includes(u)){ indeg[a.id]--; if(indeg[a.id]===0) q.push(a.id); } });
  }
  const ES = {}, EF = {};
  topo.forEach(id=>{ const act = map[id]; const es = Math.max(0, ...act.preds.map(p=> EF[p]||0)); ES[id]=es; EF[id]=es+act.duration; });
  const LS = {}, LF = {};
  const lastTime = Math.max(...Object.values(EF));
  topo.slice().reverse().forEach(id=>{ const act=map[id]; const lf = Math.min(...activities.filter(a=> a.preds.includes(id)).map(a=> LS[a.id]).filter(x=>x!==undefined));
    if(isNaN(lf)) { LF[id]=lastTime; } else { LF[id]=lf; }
    LS[id]=LF[id]-act.duration;
  });
  const slack = {};
  activities.forEach(a=>{ slack[a.id]=LS[a.id]-ES[a.id]; });
  const critical = activities.filter(a=> Math.abs(slack[a.id])<1e-9).map(a=>a.id);
  return {ES,EF,LS,LF,slack,critical,lastTime};
}
if(typeof window!=='undefined') window.DecaylaPERT = { computePERT };
