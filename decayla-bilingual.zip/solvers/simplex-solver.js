// solvers/simplex-solver.js
function cloneMatrix(m){ return m.map(r=>r.slice()); }

function pivot(tableau, row, col){
  const m = tableau.length, n = tableau[0].length;
  const pivotVal = tableau[row][col];
  for(let j=0;j<n;j++) tableau[row][j] /= pivotVal;
  for(let i=0;i<m;i++){
    if(i===row) continue;
    const factor = tableau[i][col];
    for(let j=0;j<n;j++) tableau[i][j] -= factor * tableau[row][j];
  }
}

// Problem format convenience: maximize c^T x s.t. A x (<=,=,>=) b
// constraints: array of {coeff:[...], sign: '<=' | '>=' | '=', b: number}
// c: objective coefficients
function solveLP({c, constraints}){
  const m = constraints.length;
  const n = c.length;
  let A = constraints.map(row=>row.coeff.slice());
  let b = constraints.map(row=>row.b);
  let signs = constraints.map(row=>row.sign);

  let varNames = [];
  for(let i=0;i<n;i++) varNames.push('x'+(i+1));

  let slackCount=0, artCount=0;
  for(let i=0;i<m;i++){
    if(signs[i]==='<='){
      slackCount++;
      for(let r=0;r<m;r++) A[r].push(r===i?1:0);
      varNames.push('s'+slackCount);
    } else if(signs[i]==='>='){
      slackCount++; artCount++;
      for(let r=0;r<m;r++) A[r].push(r===i?-1:0);
      varNames.push('s'+slackCount);
      for(let r=0;r<m;r++) A[r].push(r===i?1:0);
      varNames.push('a'+artCount);
    } else {
      artCount++;
      for(let r=0;r<m;r++) A[r].push(r===i?1:0);
      varNames.push('a'+artCount);
    }
  }

  const totalVars = A[0].length;

  function buildTableauWithObj(objC){
    const T = [];
    for(let i=0;i<m;i++){
      T.push(A[i].slice());
      T[i].push(b[i]);
    }
    const objRow = new Array(totalVars).fill(0);
    for(let i=0;i<objC.length;i++) objRow[i] = objC[i];
    objRow.push(0);
    T.push(objRow);
    return T;
  }

  const artIndices = [];
  for(let i=0;i<varNames.length;i++) if(varNames[i].startsWith('a')) artIndices.push(i);

  const objPhase1 = new Array(totalVars).fill(0);
  artIndices.forEach(i=> objPhase1[i] = -1);

  let tableau = buildTableauWithObj(objPhase1);

  for(const j of artIndices){
    for(let i=0;i<m;i++){
      if(Math.abs(tableau[i][j] - 1) < 1e-9){
        for(let k=0;k<tableau[0].length;k++) tableau[m][k] -= tableau[i][k];
        break;
      }
    }
  }

  function iterateSimplex(T){
    const rows = T.length, cols = T[0].length;
    const obj = T[rows-1];
    let entering = -1; let mostNeg = 1e-9;
    for(let j=0;j<cols-1;j++){
      if(obj[j] < mostNeg){ mostNeg = obj[j]; entering = j; }
    }
    if(entering===-1) return {status:'optimal'};
    let minRatio = Infinity; let leaving = -1;
    for(let i=0;i<rows-1;i++){
      const a = T[i][entering];
      if(a>1e-9){
        const ratio = T[i][cols-1] / a;
        if(ratio < minRatio - 1e-9){ minRatio = ratio; leaving = i; }
      }
    }
    if(leaving===-1) return {status:'unbounded'};
    pivot(T, leaving, entering);
    return {status:'continue'};
  }

  let iterLimit = 2000; let it=0; let res;
  while(it++<iterLimit){ res = iterateSimplex(tableau); if(res.status!=='continue') break; }
  if(res.status==='unbounded') return {status:'unbounded'};
  if(res.status!=='optimal') return {status:'infeasible'};
  const phase1Value = tableau[tableau.length-1][tableau[0].length-1];
  if(Math.abs(phase1Value) > 1e-6) return {status:'infeasible'};

  const objPhase2 = new Array(totalVars).fill(0);
  for(let i=0;i<n;i++) objPhase2[i] = -c[i];

  const keepCols = [];
  for(let j=0;j<totalVars;j++) if(!varNames[j].startsWith('a')) keepCols.push(j);

  const T2 = [];
  for(let i=0;i<=m;i++){
    const row = [];
    for(const j of keepCols) row.push(tableau[i][j]);
    row.push(tableau[i][tableau[0].length-1]);
    T2.push(row);
  }
  const objRow = new Array(keepCols.length+1).fill(0);
  for(let idx=0;idx<keepCols.length;idx++){
    const j = keepCols[idx];
    objRow[idx] = objPhase2[j] || 0;
  }
  objRow[objRow.length-1] = 0;
  T2[T2.length-1] = objRow;

  let it2=0; res=null;
  while(it2++<iterLimit){ res = iterateSimplex(T2); if(res.status!=='continue') break; }
  if(res.status==='unbounded') return {status:'unbounded'};
  if(res.status!=='optimal') return {status:'error'};

  const rows = T2.length, cols = T2[0].length;
  const sol = new Array(keepCols.length).fill(0);
  for(let j=0;j<keepCols.length;j++){
    let foundRow=-1; let found=true;
    for(let i=0;i<rows-1;i++){
      if(Math.abs(T2[i][j]-1) < 1e-9){
        for(let k=0;k<rows-1;k++){ if(k!==i && Math.abs(T2[k][j])>1e-9) { found=false; break; } }
        if(found){ foundRow=i; break; }
      }
    }
    if(foundRow!==-1) sol[j] = T2[foundRow][cols-1];
  }

  const resultSolution = {};
  for(let idx=0; idx<keepCols.length; idx++){
    const name = varNames[keepCols[idx]];
    resultSolution[name] = sol[idx];
  }
  const optVal = T2[rows-1][cols-1];
  return {status:'optimal', value: optVal, solution: resultSolution};
}

if(typeof window!=='undefined') window.DecaylaSimplex = { solveLP };
