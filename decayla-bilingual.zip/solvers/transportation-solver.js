// solvers/transportation-solver.js
function vogelInitial(supply, demand, cost){
  const m=supply.length, n=demand.length;
  const alloc = Array.from({length:m}, ()=> new Array(n).fill(null));
  const s = supply.slice(); const d = demand.slice();
  while(true){
    if(s.every(x=>Math.abs(x) < 1e-9) && d.every(x=>Math.abs(x) < 1e-9)) break;
    const rowPen = new Array(m).fill(-Infinity);
    const colPen = new Array(n).fill(-Infinity);
    for(let i=0;i<m;i++){
      const costs = [];
      for(let j=0;j<n;j++) if(alloc[i][j]===null) costs.push(cost[i][j]);
      if(costs.length>=2){ costs.sort((a,b)=>a-b); rowPen[i]=costs[1]-costs[0]; }
      else if(costs.length===1) rowPen[i]=costs[0];
    }
    for(let j=0;j<n;j++){
      const costs=[];
      for(let i=0;i<m;i++) if(alloc[i][j]===null) costs.push(cost[i][j]);
      if(costs.length>=2){ costs.sort((a,b)=>a-b); colPen[j]=costs[1]-costs[0]; }
      else if(costs.length===1) colPen[j]=costs[0];
    }
    let maxR = Math.max(...rowPen); let maxC = Math.max(...colPen);
    let isRow = maxR >= maxC; let idx = isRow ? rowPen.indexOf(maxR) : colPen.indexOf(maxC);
    let i0 = isRow ? idx : -1; let j0 = isRow ? -1 : idx;
    let bestCell = null; let bestCost = Infinity;
    if(isRow){
      for(let j=0;j<n;j++) if(alloc[i0][j]===null && cost[i0][j] < bestCost){ bestCost = cost[i0][j]; bestCell=[i0,j]; }
    } else {
      for(let i=0;i<m;i++) if(alloc[i][j0]===null && cost[i][j0] < bestCost){ bestCost = cost[i][j0]; bestCell=[i,j0]; }
    }
    const [i,j] = bestCell;
    const q = Math.min(s[i], d[j]);
    alloc[i][j] = q;
    s[i] -= q; d[j] -= q;
    if(Math.abs(s[i])<1e-9) for(let jj=0;jj<n;jj++) if(alloc[i][jj]===null) alloc[i][jj]=null;
    if(Math.abs(d[j])<1e-9) for(let ii=0;ii<m;ii++) if(alloc[ii][j]===null) alloc[ii][j]=null;
  }
  return alloc;
}

function computeCost(alloc, cost){
  let sum=0; for(let i=0;i<alloc.length;i++) for(let j=0;j<alloc[0].length;j++) if(alloc[i][j]!=null) sum += alloc[i][j]*cost[i][j];
  return sum;
}

if(typeof window!=='undefined') window.DecaylaTransport = { vogelInitial, computeCost };
