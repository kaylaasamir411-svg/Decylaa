// solvers/decision-tree.js
function evalTree(node){
  if(node.type==='terminal') return {value: node.value};
  if(node.type==='chance'){
    let ev = 0; for(const b of node.branches){ const r = evalTree(b.node); ev += b.prob * r.value; }
    return {value: ev};
  }
  if(node.type==='decision'){
    let best = null;
    for(const opt of node.options){ const r = evalTree(opt.node); if(!best || r.value > best.value) best = {value:r.value, choice:opt.name}; }
    return {value: best.value, choice: best.choice};
  }
}
if(typeof window!=='undefined') window.DecisionTreeEval = { evalTree };
