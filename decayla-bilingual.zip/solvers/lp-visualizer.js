// solvers/lp-visualizer.js
function drawLP2D(canvas, {c, constraints, xRange=[0,50], yRange=[0,50]}){
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  ctx.clearRect(0,0,W,H);
  function toCanvas(pt){
    const [x,y]=pt; const cx = (x - xRange[0])/(xRange[1]-xRange[0])*W; const cy = H - (y - yRange[0])/(yRange[1]-yRange[0])*H; return [cx,cy];
  }
  ctx.strokeStyle = '#aaa'; ctx.beginPath(); ctx.moveTo(0,H); ctx.lineTo(W,H); ctx.moveTo(0,0); ctx.lineTo(0,H); ctx.stroke();
  const samples=[];
  const gx=150, gy=150;
  for(let i=0;i<=gx;i++) for(let j=0;j<=gy;j++){
    const x = xRange[0] + (i/gx)*(xRange[1]-xRange[0]);
    const y = yRange[0] + (j/gy)*(yRange[1]-yRange[0]);
    let ok = true;
    for(const row of constraints){
      const s = row.coeff[0]*x + row.coeff[1]*y - row.b;
      if(row.sign==='<=') if(s>1e-6) {ok=false; break;}
      if(row.sign==='>=') if(s<-1e-6) {ok=false; break;}
      if(row.sign==='=') if(Math.abs(s)>1e-6) {ok=false; break;}
    }
    if(ok) samples.push([x,y]);
  }
  if(samples.length){
    ctx.fillStyle = 'rgba(50,150,200,0.12)'; ctx.beginPath();
    for(let k=0;k<samples.length;k++){ const [cx,cy] = toCanvas(samples[k]); if(k===0) ctx.moveTo(cx,cy); else ctx.lineTo(cx,cy); }
    ctx.closePath(); ctx.fill();
  }
  ctx.strokeStyle='#333'; ctx.lineWidth=1;
  for(const row of constraints){
    const a=row.coeff[0], b=row.coeff[1], c_=row.b;
    const p1 = [xRange[0], (c_-a*xRange[0])/(b||1e-9)];
    const p2 = [xRange[1], (c_-a*xRange[1])/(b||1e-9)];
    const [cx1,cy1]=toCanvas(p1); const [cx2,cy2]=toCanvas(p2);
    ctx.beginPath(); ctx.moveTo(cx1,cy1); ctx.lineTo(cx2,cy2); ctx.stroke();
  }
  const sol = window.DecaylaSimplex.solveLP({c, constraints});
  if(sol.status==='optimal'){
    const x1 = sol.solution.x1 || sol.solution['x1'] || 0;
    const x2 = sol.solution.x2 || sol.solution['x2'] || 0;
    const [cx,cy]=toCanvas([x1,x2]); ctx.fillStyle='#d33'; ctx.beginPath(); ctx.arc(cx,cy,6,0,2*Math.PI); ctx.fill();
    ctx.fillStyle='#000'; ctx.fillText('Optimal ('+x1.toFixed(2)+', '+x2.toFixed(2)+')', cx+8, cy-8);
  }
}
if(typeof window!=='undefined') window.DecaylaLPVis = { drawLP2D };
